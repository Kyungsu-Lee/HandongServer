package WebParsing;

public class gongji {
	String title, num, gongjiURL;
	String contents, attachFileURL;

	public gongji(){}
	public String getTitle() {return title;}
	public void setTitle(String title) {this.title = title;}

	public String getNum() {return num;}
	public void setNum(String num) {this.num = num;}
	
	public String getGongjiURL(){return gongjiURL;}
	public void setGongjiURL(String gongjiURL){this.gongjiURL = gongjiURL;}
	
	
	public String getContents(){return contents;}
	public void setContents(String contents){this.contents = contents;}
	
	public String getAttachFileURL(){return attachFileURL;}
	public void setAttachFileURL(String attachFileURL){this.attachFileURL = attachFileURL;}
}
